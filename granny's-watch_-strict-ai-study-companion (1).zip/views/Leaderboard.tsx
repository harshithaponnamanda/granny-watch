import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { StatsService } from '../services/StatsService';
import { LeaderboardEntry, UserStats } from '../types';
import { RANK_PHRASES, TIERS, BADGES } from '../constants';

interface LeaderboardProps {
  onBack: () => void;
}

export const Leaderboard: React.FC<LeaderboardProps> = ({ onBack }) => {
  const [filter, setFilter] = useState<'all' | 'weekly'>('all');
  const [stats, setStats] = useState<UserStats>(StatsService.getUserStats());
  const [list, setList] = useState<LeaderboardEntry[]>([]);

  useEffect(() => {
    setList(StatsService.getLeaderboard(filter));
  }, [filter]);

  const getGrannyComment = () => {
    if (stats.rank <= 3) return RANK_PHRASES.TOP;
    if (stats.rank <= 20) return RANK_PHRASES.HIGH;
    if (stats.rank <= 50) return RANK_PHRASES.MID;
    return RANK_PHRASES.LOW;
  };

  return (
    <div className="flex flex-col items-center min-h-screen pt-12 pb-24 px-4 w-full max-w-4xl mx-auto">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-12"
      >
        <h2 className="text-5xl font-serif text-amber-500 mb-4 uppercase tracking-tighter">Global Scholar Ranking</h2>
        <div className="bg-slate-900/60 backdrop-blur-md px-8 py-4 rounded-2xl border border-slate-800 shadow-xl inline-block">
          <p className="text-rose-400 font-classic italic text-lg">"{getGrannyComment()}"</p>
        </div>
      </motion.div>

      {/* User Status Card */}
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full bg-gradient-to-r from-slate-900 to-slate-950 p-8 rounded-[40px] border-2 border-amber-500/30 mb-12 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-8"
      >
        <div className="flex items-center gap-6">
          <div className="relative">
            <div className="w-20 h-20 rounded-full bg-slate-800 flex items-center justify-center text-4xl border-2 border-amber-500">
              👤
            </div>
            <div className="absolute -bottom-2 -right-2 bg-amber-600 text-[10px] font-bold px-3 py-1 rounded-full text-white shadow-lg">
              {stats.tier}
            </div>
          </div>
          <div>
            <h3 className="text-2xl font-serif text-white">{stats.username}</h3>
            <p className="text-slate-500 text-xs uppercase tracking-[0.2em] font-bold">Current Rank: #{stats.rank}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-8 text-center md:text-right">
          <div>
            <div className="text-3xl font-serif text-amber-500">{Math.round(stats.totalFocusMinutes / 60)}h</div>
            <div className="text-[10px] uppercase text-slate-500 tracking-widest font-bold">Total Focus</div>
          </div>
          <div>
            <div className="text-3xl font-serif text-emerald-500">{BADGES.filter(b => (stats.totalFocusMinutes/60) >= b.requirement).length}</div>
            <div className="text-[10px] uppercase text-slate-500 tracking-widest font-bold">Badges</div>
          </div>
        </div>
      </motion.div>

      {/* Tabs */}
      <div className="flex gap-4 mb-8 bg-slate-900/40 p-1.5 rounded-2xl border border-slate-800">
        <button 
          onClick={() => setFilter('all')}
          className={`px-8 py-2 rounded-xl text-sm font-bold transition-all ${filter === 'all' ? 'bg-amber-600 text-white' : 'text-slate-500 hover:text-slate-300'}`}
        >
          All Time
        </button>
        <button 
          onClick={() => setFilter('weekly')}
          className={`px-8 py-2 rounded-xl text-sm font-bold transition-all ${filter === 'weekly' ? 'bg-amber-600 text-white' : 'text-slate-500 hover:text-slate-300'}`}
        >
          Weekly
        </button>
      </div>

      {/* List */}
      <div className="w-full space-y-4">
        <AnimatePresence mode="popLayout">
          {list.map((entry, i) => (
            <motion.div
              key={`${entry.username}-${i}`}
              layout
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
              className={`flex items-center justify-between p-6 rounded-[30px] border transition-all ${
                entry.isCurrentUser 
                ? 'bg-amber-500/10 border-amber-500/50 shadow-[0_0_30px_rgba(245,158,11,0.1)]' 
                : 'bg-slate-900/40 border-slate-800'
              }`}
            >
              <div className="flex items-center gap-6">
                <div className={`w-10 h-10 flex items-center justify-center font-serif text-xl ${
                  entry.rank === 1 ? 'text-amber-400' : entry.rank === 2 ? 'text-slate-300' : entry.rank === 3 ? 'text-orange-500' : 'text-slate-600'
                }`}>
                  #{entry.rank}
                </div>
                <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center text-xl">
                  {entry.avatarId === 'granny' ? '👵' : '👔'}
                </div>
                <div>
                  <div className="font-serif text-lg text-white flex items-center gap-2">
                    {entry.username}
                    {entry.isCurrentUser && <span className="text-[10px] bg-amber-600 text-white px-2 py-0.5 rounded-full uppercase">You</span>}
                  </div>
                  <div className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">{entry.country} • {entry.hours > 200 ? 'Master' : 'Student'}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xl font-serif text-white">{entry.hours}h</div>
                <div className="text-[9px] text-slate-500 uppercase font-bold tracking-tighter">Focused Work</div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Sticky Action Button */}
      <div className="fixed bottom-8 left-0 w-full flex justify-center pointer-events-none">
        <button
          onClick={onBack}
          className="pointer-events-auto bg-slate-900 hover:bg-slate-800 text-white font-bold py-4 px-12 rounded-full border border-slate-700 shadow-2xl transition-all transform hover:scale-105 active:scale-95 flex items-center gap-3 group"
        >
          <span className="text-amber-500 group-hover:-translate-x-1 transition-transform">←</span>
          Return to Study Hall
        </button>
      </div>
    </div>
  );
};