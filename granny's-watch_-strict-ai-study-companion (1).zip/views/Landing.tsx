import React from 'react';
import { motion } from 'framer-motion';
import { GrannyCharacter } from '../components/GrannyCharacter';
import { GrannyState, User } from '../types';
import { AuthService } from '../services/AuthService';

interface LandingProps {
  onStart: () => void;
  onAuth: () => void;
  user: User | null;
  onLogout: () => void;
}

export const Landing: React.FC<LandingProps> = ({ onStart, onAuth, user, onLogout }) => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[85vh] px-4 text-center">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <h1 className="text-6xl md:text-8xl font-serif mb-4 text-amber-500 tracking-tight drop-shadow-2xl">
          Granny's Watch
        </h1>
        <p className="text-xl md:text-3xl font-classic text-slate-400 italic mb-8 max-w-2xl">
          "Discipline is the bridge between goals and accomplishment."
        </p>
      </motion.div>

      <motion.div
        initial={{ scale: 0.85, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.7 }}
        className="mb-8 relative"
      >
        <div className="absolute inset-0 bg-amber-500/5 blur-[100px] rounded-full" />
        <GrannyCharacter state={GrannyState.WATCHING} />
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8 }}
        className="max-w-md z-10"
      >
        <h2 className="text-sm font-bold mb-6 text-rose-500 uppercase tracking-[0.4em]">Proprietary Monitoring Protocol</h2>
        <p className="text-slate-400 mb-10 leading-relaxed font-classic text-lg italic">
          {user ? `Welcome back, ${user.username}. Granny has been expecting you.` : "Struggling to focus? Granny will monitor your presence. If you stray from your duties or leave her sight, prepare for a scolding."}
        </p>
        
        <div className="flex flex-col gap-4">
          <button
            onClick={user ? onStart : onAuth}
            className="bg-amber-600 hover:bg-amber-700 text-white font-bold py-5 px-14 rounded-2xl transition-all duration-300 transform hover:scale-105 hover:shadow-[0_20px_40px_rgba(217,119,6,0.3)] active:scale-95 text-xl font-serif"
          >
            {user ? "Enter the Study Hall" : "Identification Required"}
          </button>
          
          {user && (
            <button 
              onClick={onLogout}
              className="text-slate-600 text-xs hover:text-rose-500 transition-colors uppercase tracking-[0.2em] font-bold"
            >
              Sign Out (Don't let the door hit you)
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
};