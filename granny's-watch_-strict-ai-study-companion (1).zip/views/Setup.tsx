import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { SessionConfig } from '../types';
import { StatsService } from '../services/StatsService';

interface SetupProps {
  onComplete: (config: SessionConfig) => void;
}

export const Setup: React.FC<SetupProps> = ({ onComplete }) => {
  const [studyTime, setStudyTime] = useState(25);
  const [breakTime, setBreakTime] = useState(5);
  const [maxSins, setMaxSins] = useState(3);
  const [username, setUsername] = useState('');

  useEffect(() => {
    const stats = StatsService.getUserStats();
    if (stats.username && stats.username !== 'New Scholar') {
      setUsername(stats.username);
    }
  }, []);

  const handleStart = () => {
    const finalUsername = username.trim() || 'Scholar-' + Math.floor(Math.random() * 9000);
    StatsService.saveProfile(finalUsername, 'granny');
    onComplete({ 
      studyDuration: studyTime, 
      breakDuration: breakTime, 
      maxDistractions: maxSins,
      character: 'Granny',
      username: finalUsername
    });
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] px-4 max-w-xl mx-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full bg-slate-950/80 backdrop-blur-xl p-10 rounded-3xl border border-slate-800 shadow-[0_0_50px_rgba(0,0,0,0.5)]"
      >
        <h2 className="text-3xl font-serif mb-10 text-amber-500 text-center uppercase tracking-widest">Protocol Configuration</h2>
        
        <div className="space-y-10">
          <div>
            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest block mb-4">Your Identifier</label>
            <input 
              type="text"
              placeholder="Enter Username..."
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-6 py-4 text-white focus:outline-none focus:border-amber-500 transition-colors font-serif text-lg"
            />
          </div>

          <div>
            <div className="flex justify-between items-end mb-4">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Study Phase</label>
              <span className="text-2xl font-serif text-white">{studyTime} Minutes</span>
            </div>
            <input
              type="range" min="5" max="120" step="5" value={studyTime}
              onChange={(e) => setStudyTime(parseInt(e.target.value))}
              className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />
          </div>

          <div>
            <div className="flex justify-between items-end mb-4">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Rest Phase</label>
              <span className="text-2xl font-serif text-white">{breakTime} Minutes</span>
            </div>
            <input
              type="range" min="1" max="30" step="1" value={breakTime}
              onChange={(e) => setBreakTime(parseInt(e.target.value))}
              className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
          </div>

          <div>
            <div className="flex justify-between items-end mb-4">
              <label className="text-xs font-bold text-rose-500 uppercase tracking-widest">Allowed Sins</label>
              <span className="text-2xl font-serif text-rose-500">{maxSins === 0 ? 'HARDCORE' : maxSins}</span>
            </div>
            <input
              type="range" min="0" max="10" step="1" value={maxSins}
              onChange={(e) => setMaxSins(parseInt(e.target.value))}
              className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-600"
            />
          </div>
        </div>

        <button
          onClick={handleStart}
          className="w-full mt-12 bg-amber-600 hover:bg-amber-700 text-white font-bold py-5 rounded-2xl transition-all shadow-[0_10px_30px_rgba(217,119,6,0.3)] hover:-translate-y-1 active:translate-y-0 text-xl font-serif"
        >
          I Accept the Terms
        </button>
      </motion.div>
    </div>
  );
};