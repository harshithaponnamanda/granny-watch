import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { GrannyCharacter } from '../components/GrannyCharacter';
import { SpeechBubble } from '../components/SpeechBubble';
import { SessionConfig, SessionMode, GrannyState } from '../types';
import { SCOLDING_PHRASES, ENCOURAGING_PHRASES, SLEEP_PHRASES } from '../constants';
import { StatsService } from '../services/StatsService';

interface SessionProps {
  config: SessionConfig;
  onFinish: () => void;
}

export const Session: React.FC<SessionProps> = ({ config, onFinish }) => {
  const [mode, setMode] = useState<SessionMode>(SessionMode.STUDY);
  const [timeLeft, setTimeLeft] = useState(config.studyDuration * 60);
  const [grannyState, setGrannyState] = useState<GrannyState>(GrannyState.WATCHING);
  const [currentQuote, setCurrentQuote] = useState("Begin your work, child.");
  const [distractions, setDistractions] = useState(0);
  const [lockdown, setLockdown] = useState(false);
  const [streak, setStreak] = useState(0);
  const [totalFocusedSeconds, setTotalFocusedSeconds] = useState(0);
  
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const quoteTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Sound Refs
  const sounds = useRef({
    tick: new Audio('https://www.soundjay.com/buttons/sounds/button-20.mp3'),
    start: new Audio('https://www.soundjay.com/misc/sounds/bell-ringing-05.mp3'),
    end: new Audio('https://www.soundjay.com/clock/sounds/desk-bell-one-time-01.mp3'),
    scold: new Audio('https://www.soundjay.com/misc/sounds/wood-crack-01.mp3'),
    praise: new Audio('https://www.soundjay.com/misc/sounds/magic-chime-01.mp3'),
  });

  const playSound = (soundKey: keyof typeof sounds.current, volume = 0.5) => {
    const audio = sounds.current[soundKey];
    if (audio) {
      audio.volume = volume;
      audio.currentTime = 0;
      audio.play().catch(() => {
        // Autoplay policy might block initially, silent fail is better than error
      });
    }
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const updateGrannyMood = useCallback((isDistracted: boolean) => {
    if (mode !== SessionMode.STUDY) return;

    if (isDistracted) {
      const newCount = distractions + 1;
      setDistractions(newCount);
      setStreak(0);
      playSound('scold', 0.6);

      if (newCount >= config.maxDistractions && config.maxDistractions !== 0) {
        setGrannyState(GrannyState.ANGRY);
        setLockdown(true);
        setCurrentQuote("ENOUGH! Sit back and study. I am locking the doors!");
      } else {
        setGrannyState(GrannyState.SUSPICIOUS);
        setCurrentQuote(SCOLDING_PHRASES[Math.floor(Math.random() * SCOLDING_PHRASES.length)]);
      }

      setTimeout(() => {
        setGrannyState(prev => (newCount >= config.maxDistractions ? GrannyState.ANGRY : GrannyState.WATCHING));
      }, 8000);
    } else {
      if (streak > 30) {
        if (grannyState !== GrannyState.IDLE) playSound('praise', 0.2);
        setGrannyState(GrannyState.IDLE); 
      } else {
        setGrannyState(GrannyState.WATCHING);
      }
    }
  }, [distractions, mode, config, streak, grannyState]);

  // Initial Session Start Sound
  useEffect(() => {
    playSound('start', 0.4);
  }, []);

  useEffect(() => {
    const handleDistractionEvent = () => {
      if (document.hidden && mode === SessionMode.STUDY) {
        updateGrannyMood(true);
      }
    };
    const handleBlur = () => {
      if (mode === SessionMode.STUDY) {
        updateGrannyMood(true);
      }
    };
    window.addEventListener('visibilitychange', handleDistractionEvent);
    window.addEventListener('blur', handleBlur);
    return () => {
      window.removeEventListener('visibilitychange', handleDistractionEvent);
      window.removeEventListener('blur', handleBlur);
    };
  }, [updateGrannyMood, mode]);

  useEffect(() => {
    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 0) {
          if (mode === SessionMode.STUDY) {
            playSound('end', 0.5);
            // Study phase finished - Save Stats
            StatsService.updateFocusTime(Math.round(totalFocusedSeconds / 60));
            
            setMode(SessionMode.BREAK);
            setGrannyState(GrannyState.SLEEPING);
            setCurrentQuote("I'm resting my eyes... don't be loud.");
            setLockdown(false);
            return config.breakDuration * 60;
          } else {
            playSound('start', 0.3); // Returning from break
            setMode(SessionMode.FINISHED);
            if (timerRef.current) clearInterval(timerRef.current);
            return 0;
          }
        }
        
        // Subtle Tick
        if (mode === SessionMode.STUDY && !document.hidden) {
          playSound('tick', 0.05); // Very subtle tick
          setStreak(s => s + 1);
          setTotalFocusedSeconds(s => s + 1);
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [mode, config, totalFocusedSeconds]);

  useEffect(() => {
    quoteTimerRef.current = setInterval(() => {
      if (mode === SessionMode.STUDY && !lockdown) {
        if (grannyState === GrannyState.IDLE) {
          playSound('praise', 0.15);
          setCurrentQuote(ENCOURAGING_PHRASES[Math.floor(Math.random() * ENCOURAGING_PHRASES.length)]);
        } else if (grannyState === GrannyState.WATCHING) {
          setCurrentQuote("I see you. My glasses are clean today.");
        }
      }
    }, 20000);
    return () => {
      if (quoteTimerRef.current) clearInterval(quoteTimerRef.current);
    };
  }, [grannyState, mode, lockdown]);

  if (mode === SessionMode.FINISHED) {
    const disciplineScore = Math.max(0, 100 - (distractions * 10));
    return (
      <div className="flex flex-col items-center justify-center min-h-[85vh] text-center p-4">
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="mb-12">
          <GrannyCharacter state={GrannyState.WATCHING} />
        </motion.div>
        <h2 className="text-6xl font-serif text-amber-500 mb-2 uppercase tracking-tight">Session Results</h2>
        <p className="text-2xl font-classic text-slate-400 mb-12 italic max-w-lg">
          {disciplineScore > 80 ? '"Remarkable. You have potential, after all."' : '"At least you finished. Now go, I need my tea."'}
        </p>
        
        <div className="grid grid-cols-3 gap-8 mb-16 w-full max-w-4xl px-4">
          <div className="bg-slate-900/60 p-10 rounded-[40px] border border-slate-800 shadow-2xl">
            <div className="text-5xl font-serif text-amber-500 mb-2">{config.studyDuration}m</div>
            <div className="text-xs uppercase tracking-[0.3em] text-slate-500 font-bold">Labor Input</div>
          </div>
          <div className="bg-slate-900/60 p-10 rounded-[40px] border border-slate-800 shadow-2xl">
            <div className={`text-5xl font-serif ${disciplineScore > 70 ? 'text-emerald-500' : 'text-rose-500'} mb-2`}>
              {disciplineScore}%
            </div>
            <div className="text-xs uppercase tracking-[0.3em] text-slate-500 font-bold">Discipline Rating</div>
          </div>
          <div className="bg-slate-900/60 p-10 rounded-[40px] border border-slate-800 shadow-2xl">
            <div className="text-5xl font-serif text-amber-500 mb-2">{distractions}</div>
            <div className="text-xs uppercase tracking-[0.3em] text-slate-500 font-bold">Total Sins</div>
          </div>
        </div>

        <button
          onClick={onFinish}
          className="bg-amber-600 hover:bg-amber-700 text-white font-bold py-5 px-20 rounded-2xl shadow-xl transition-all hover:-translate-y-1 font-serif text-2xl"
        >
          Return to Hall
        </button>
      </div>
    );
  }

  return (
    <div className="relative flex flex-col items-center justify-center min-h-[92vh] p-4 overflow-hidden bg-slate-950">
      {/* HUD Header */}
      <div className="fixed top-0 left-0 w-full p-10 flex justify-between items-start z-40 pointer-events-none">
        <div className="space-y-6">
          <div className="bg-slate-950/90 backdrop-blur-xl p-6 rounded-3xl border border-slate-800 w-56 shadow-2xl">
            <div className="text-[10px] font-bold text-slate-600 uppercase tracking-[0.3em] mb-2">Watcher Status</div>
            <div className={`text-base font-bold flex items-center gap-3 transition-colors ${
              grannyState === GrannyState.ANGRY ? 'text-rose-500' : 
              grannyState === GrannyState.SUSPICIOUS ? 'text-orange-500' :
              grannyState === GrannyState.SLEEPING ? 'text-blue-500' : 'text-emerald-500'
            }`}>
              <div className="w-2.5 h-2.5 rounded-full bg-current animate-pulse shadow-[0_0_10px_currentColor]" />
              {grannyState.replace('_', ' ')}
            </div>
          </div>
        </div>

        <div className="bg-slate-950/90 backdrop-blur-xl p-6 rounded-3xl border border-slate-800 w-56 shadow-2xl">
          <div className="text-[10px] font-bold text-rose-500 uppercase tracking-[0.3em] mb-2 text-right">Sin Tally</div>
          <div className="text-3xl font-serif text-rose-500 text-right">{distractions} <span className="text-slate-700 text-xl mx-1">/</span> {config.maxDistractions}</div>
        </div>
      </div>

      <div className="z-10 flex flex-col items-center gap-8 w-full max-w-6xl">
        <GrannyCharacter state={grannyState} />
        <SpeechBubble text={currentQuote} isAngry={grannyState === GrannyState.ANGRY || grannyState === GrannyState.SUSPICIOUS} />
        <div className="mt-8 flex flex-col items-center">
          <div className="text-8xl md:text-[10rem] font-serif text-white tracking-[0.2em]">
            {formatTime(timeLeft)}
          </div>
        </div>
      </div>
    </div>
  );
};