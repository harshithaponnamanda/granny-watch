
import React from 'react';
import { motion } from 'framer-motion';
import { GrannyCharacter } from '../components/GrannyCharacter';
import { GrannyState } from '../types';

interface CharacterSelectProps {
  onSelect: (id: string) => void;
}

export const CharacterSelect: React.FC<CharacterSelectProps> = ({ onSelect }) => {
  const characters = [
    { id: 'granny', name: 'Strict Granny', desc: 'She watches. She judges. She scolds.', state: GrannyState.WATCHING, color: 'border-amber-500 shadow-amber-500/20' },
    { id: 'asian_mom', name: 'Asian Mom', desc: 'Coming Soon: Unmatched Expectations.', state: GrannyState.DISAPPOINTED, color: 'border-slate-800 opacity-40 cursor-not-allowed', locked: true },
    { id: 'teacher', name: 'Strict Teacher', desc: 'Coming Soon: The Red Pen is Ready.', state: GrannyState.SUSPICIOUS, color: 'border-slate-800 opacity-40 cursor-not-allowed', locked: true },
  ];

  return (
    <div className="flex flex-col items-center justify-center min-h-[85vh] px-4 text-center py-12">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-16"
      >
        <h2 className="text-5xl font-serif text-amber-500 mb-4 uppercase tracking-widest">Identify Your Watcher</h2>
        <p className="text-slate-500 font-classic italic text-xl">"Choose the voice that keeps you honest."</p>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-10 w-full max-w-7xl px-4">
        {characters.map((char, i) => (
          <motion.div
            key={char.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.15 }}
            onClick={() => !char.locked && onSelect(char.id)}
            className={`group relative flex flex-col items-center p-10 bg-slate-900/40 rounded-[40px] border-2 transition-all duration-500 overflow-hidden ${char.color} ${!char.locked ? 'hover:scale-[1.02] hover:bg-slate-900/80 cursor-pointer shadow-2xl' : ''}`}
          >
            <div className="flex justify-center mb-8 w-full">
              <div className="transform transition-transform group-hover:scale-110 duration-500">
                <GrannyCharacter state={char.state} />
              </div>
            </div>
            <div className="mt-auto">
              <h3 className="text-3xl font-serif text-white mb-3">{char.name}</h3>
              <p className="text-slate-400 text-base font-classic italic leading-relaxed">{char.desc}</p>
            </div>

            {char.locked && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/60 backdrop-blur-[2px] rounded-[40px]">
                <div className="bg-slate-800 px-6 py-2 rounded-full border border-slate-700 shadow-xl">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-[0.3em]">Restricted Access</span>
                </div>
              </div>
            )}
            
            {/* Hover Highlight */}
            {!char.locked && (
              <div className="absolute -bottom-1 left-0 w-full h-2 bg-amber-500 opacity-0 group-hover:opacity-100 transition-opacity" />
            )}
          </motion.div>
        ))}
      </div>
    </div>
  );
};
