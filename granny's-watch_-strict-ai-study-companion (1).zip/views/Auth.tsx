import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AuthService } from '../services/AuthService';
import { GrannyCharacter } from '../components/GrannyCharacter';
import { SpeechBubble } from '../components/SpeechBubble';
import { GrannyState, User } from '../types';

interface AuthProps {
  onSuccess: (user: User) => void;
  onBack: () => void;
}

export const Auth: React.FC<AuthProps> = ({ onSuccess, onBack }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [grannyMood, setGrannyMood] = useState(GrannyState.WATCHING);
  const [quote, setQuote] = useState("Identification, please. No loafers allowed.");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setGrannyMood(GrannyState.SUSPICIOUS);
    setQuote("Let's see if your credentials match your claims...");

    try {
      let user;
      if (isLogin) {
        user = await AuthService.login(email, password);
      } else {
        user = await AuthService.signup(email, password, username);
      }
      setGrannyMood(GrannyState.IDLE);
      setQuote(isLogin ? "Ah, it's you. Don't waste my time." : "A new recruit? I hope you're not as lazy as the last one.");
      setTimeout(() => onSuccess(user), 1000);
    } catch (err: any) {
      setGrannyMood(GrannyState.ANGRY);
      
      let grannyErrorMsg = "Incompetence! Check your details and try again.";
      let feedbackQuote = "Lies! Something went wrong with your papers!";

      switch (err.message) {
        case 'WEAK_PASSWORD':
          grannyErrorMsg = "A password that weak? Your security is as thin as my morning porridge!";
          feedbackQuote = "Use at least 6 characters, lazybones! I won't have a vulnerable student!";
          break;
        case 'INCORRECT_CREDENTIALS':
          grannyErrorMsg = "Incorrect! My memory is sharp, but yours seems to be failing.";
          feedbackQuote = "Wrong key! Go back and check your scribbles!";
          break;
        case 'EMAIL_IN_USE':
          grannyErrorMsg = "That email is already in my book! Stop trying to cheat!";
          feedbackQuote = "Are you trying to duplicate yourself to avoid chores?";
          break;
        default:
          grannyErrorMsg = err.message || "An unexpected error occurred. Disgraceful.";
      }

      setError(grannyErrorMsg);
      setQuote(feedbackQuote);
      setLoading(false);
    }
  };

  const handleGoogleAuth = async () => {
    setLoading(true);
    try {
      const user = await AuthService.googleSignIn();
      onSuccess(user);
    } catch (err) {
      setError("Google doesn't want to help you study today.");
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[85vh] px-4 py-12">
      <div className="mb-8 flex flex-col items-center">
        <GrannyCharacter state={grannyMood} />
        <SpeechBubble text={quote} isAngry={grannyMood === GrannyState.ANGRY} />
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md bg-slate-900/60 backdrop-blur-xl p-10 rounded-[40px] border border-slate-800 shadow-2xl"
      >
        <div className="flex justify-center gap-8 mb-10">
          <button 
            onClick={() => { setIsLogin(true); setError(''); setQuote("Returning to the fold? Sign in then."); }}
            className={`text-sm font-bold uppercase tracking-widest transition-all ${isLogin ? 'text-amber-500 underline underline-offset-8' : 'text-slate-500'}`}
          >
            Login
          </button>
          <button 
            onClick={() => { setIsLogin(false); setError(''); setQuote("A new face? Write your name clearly."); }}
            className={`text-sm font-bold uppercase tracking-widest transition-all ${!isLogin ? 'text-amber-500 underline underline-offset-8' : 'text-slate-500'}`}
          >
            Signup
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <AnimatePresence mode="wait">
            {!isLogin && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
              >
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 block">Username</label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-4 text-white focus:outline-none focus:border-amber-500 transition-colors font-serif"
                />
              </motion.div>
            )}
          </AnimatePresence>

          <div>
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 block">Email Address</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-4 text-white focus:outline-none focus:border-amber-500 transition-colors font-serif"
            />
          </div>

          <div>
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 block">Pass-Phrase</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-4 text-white focus:outline-none focus:border-amber-500 transition-colors font-serif"
            />
          </div>

          {error && (
            <motion.p 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-rose-500 text-xs italic text-center font-semibold bg-rose-500/10 py-2 rounded-lg"
            >
              {error}
            </motion.p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-amber-600 hover:bg-amber-700 disabled:bg-slate-800 text-white font-bold py-5 rounded-2xl shadow-xl transition-all transform hover:-translate-y-1 font-serif text-xl"
          >
            {loading ? 'Granny is checking...' : isLogin ? 'Enter the Hall' : 'Enroll Now'}
          </button>
        </form>

        <div className="relative my-8">
          <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-800"></div></div>
          <div className="relative flex justify-center text-xs uppercase tracking-widest"><span className="bg-slate-900 px-4 text-slate-600">Or</span></div>
        </div>

        <button
          onClick={handleGoogleAuth}
          className="w-full bg-white text-slate-900 font-bold py-4 rounded-2xl flex items-center justify-center gap-3 hover:bg-slate-200 transition-all font-serif"
        >
          <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-5 h-5" alt="Google" />
          Authenticate via Google
        </button>

        <button 
          onClick={onBack}
          className="w-full mt-6 text-slate-500 text-xs hover:text-slate-300 transition-colors"
        >
          Never mind, I'll go play games instead
        </button>
      </motion.div>
    </div>
  );
};