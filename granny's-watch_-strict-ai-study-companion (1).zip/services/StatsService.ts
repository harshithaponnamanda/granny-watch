import { LeaderboardEntry, UserStats } from '../types';

const MOCK_COMPETITORS: LeaderboardEntry[] = [
  { rank: 1, username: 'Dr. Focus', avatarId: 'teacher', hours: 450, country: 'DE' },
  { rank: 2, username: 'ExamDestroyer', avatarId: 'granny', hours: 412, country: 'US' },
  { rank: 3, username: 'TeaSipper', avatarId: 'granny', hours: 389, country: 'GB' },
  { rank: 4, username: 'SilenceSeeker', avatarId: 'teacher', hours: 320, country: 'JP' },
  { rank: 5, username: 'NoSleepJane', avatarId: 'granny', hours: 298, country: 'CA' },
  { rank: 6, username: 'BookWorm99', avatarId: 'granny', hours: 250, country: 'IN' },
  { rank: 7, username: 'StrictlyBusiness', avatarId: 'teacher', hours: 210, country: 'FR' },
  { rank: 8, username: 'CalculusKing', avatarId: 'granny', hours: 180, country: 'KR' },
  { rank: 9, username: 'GrammarGrip', avatarId: 'teacher', hours: 155, country: 'AU' },
  { rank: 10, username: 'PencilPusher', avatarId: 'granny', hours: 120, country: 'BR' },
];

export const StatsService = {
  getUserStats: (): UserStats => {
    const stored = localStorage.getItem('granny_user_stats');
    if (stored) return JSON.parse(stored);
    
    return {
      username: 'New Scholar',
      totalFocusMinutes: 0,
      weeklyFocusMinutes: 0,
      sinsCount: 0,
      avatarId: 'granny',
      rank: 101,
      tier: 'Bronze'
    };
  },

  updateFocusTime: (minutes: number) => {
    const stats = StatsService.getUserStats();
    stats.totalFocusMinutes += minutes;
    stats.weeklyFocusMinutes += minutes;
    
    // Update tier
    const hours = stats.totalFocusMinutes / 60;
    if (hours >= 500) stats.tier = 'Diamond';
    else if (hours >= 200) stats.tier = 'Gold';
    else if (hours >= 50) stats.tier = 'Silver';
    else stats.tier = 'Bronze';

    // Update Rank (Mock logic)
    stats.rank = Math.max(1, 1000 - Math.floor(stats.totalFocusMinutes / 5));

    localStorage.setItem('granny_user_stats', JSON.stringify(stats));
    return stats;
  },

  saveProfile: (username: string, avatarId: string) => {
    const stats = StatsService.getUserStats();
    stats.username = username;
    stats.avatarId = avatarId;
    localStorage.setItem('granny_user_stats', JSON.stringify(stats));
  },

  getLeaderboard: (period: 'all' | 'weekly'): LeaderboardEntry[] => {
    const userStats = StatsService.getUserStats();
    const userEntry: LeaderboardEntry = {
      rank: userStats.rank,
      username: userStats.username,
      avatarId: userStats.avatarId,
      hours: Math.round(userStats.totalFocusMinutes / 60),
      isCurrentUser: true,
      country: 'LOCAL'
    };

    const list = [...MOCK_COMPETITORS];
    if (userStats.rank <= 10) {
      list.splice(userStats.rank - 1, 0, userEntry);
    } else {
      list.push(userEntry);
    }
    
    return list.sort((a, b) => b.hours - a.hours).map((item, idx) => ({ ...item, rank: idx + 1 }));
  }
};