import { User } from '../types';

const AUTH_KEY = 'granny_auth_session';

export const AuthService = {
  getCurrentUser: (): User | null => {
    const session = localStorage.getItem(AUTH_KEY);
    return session ? JSON.parse(session) : null;
  },

  login: async (email: string, password: string): Promise<User> => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    // Simulate incorrect credentials
    if (email === 'wrong@test.com' || password === 'wrong') {
      throw new Error("INCORRECT_CREDENTIALS");
    }

    if (password.length < 6) {
      throw new Error("WEAK_PASSWORD");
    }
    
    const user: User = {
      id: btoa(email),
      email,
      username: email.split('@')[0],
      avatarId: 'granny'
    };
    
    localStorage.setItem(AUTH_KEY, JSON.stringify(user));
    return user;
  },

  signup: async (email: string, password: string, username: string): Promise<User> => {
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Simulate email already in use
    if (email === 'taken@test.com') {
      throw new Error("EMAIL_IN_USE");
    }

    if (password.length < 6) {
      throw new Error("WEAK_PASSWORD");
    }
    
    const user: User = {
      id: btoa(email),
      email,
      username: username || email.split('@')[0],
      avatarId: 'granny'
    };
    
    localStorage.setItem(AUTH_KEY, JSON.stringify(user));
    return user;
  },

  logout: () => {
    localStorage.removeItem(AUTH_KEY);
  },

  googleSignIn: async (): Promise<User> => {
    // Mock Google OAuth
    await new Promise(resolve => setTimeout(resolve, 1000));
    const user: User = {
      id: 'google-123',
      email: 'scholar@gmail.com',
      username: 'GoogleScholar',
      avatarId: 'granny'
    };
    localStorage.setItem(AUTH_KEY, JSON.stringify(user));
    return user;
  }
};