export enum AppView {
  LANDING = 'LANDING',
  AUTH = 'AUTH',
  CHARACTER_SELECT = 'CHARACTER_SELECT',
  SETUP = 'SETUP',
  SESSION = 'SESSION',
  LEADERBOARD = 'LEADERBOARD'
}

export enum GrannyState {
  IDLE = 'IDLE', 
  WATCHING = 'WATCHING', 
  SUSPICIOUS = 'SUSPICIOUS', 
  ANGRY = 'ANGRY', 
  SLEEPING = 'SLEEPING',
  DISAPPOINTED = 'DISAPPOINTED'
}

export enum SessionMode {
  STUDY = 'STUDY',
  BREAK = 'BREAK',
  FINISHED = 'FINISHED'
}

export interface User {
  id: string;
  email: string;
  username: string;
  avatarId: string;
}

export interface SessionConfig {
  studyDuration: number; // minutes
  breakDuration: number; // minutes
  maxDistractions: number; 
  character: string;
  username: string;
}

export interface Badge {
  id: string;
  name: string;
  icon: string;
  requirement: number; // hours
  unlocked: boolean;
}

export interface UserStats {
  username: string;
  totalFocusMinutes: number;
  weeklyFocusMinutes: number;
  sinsCount: number;
  avatarId: string;
  rank: number;
  tier: 'Bronze' | 'Silver' | 'Gold' | 'Diamond';
}

export interface LeaderboardEntry {
  rank: number;
  username: string;
  avatarId: string;
  hours: number;
  isCurrentUser?: boolean;
  country: string;
}