import React from 'react';

export const SCOLDING_PHRASES = [
  "Why are you touching your phone? Education is a privilege!",
  "Is that a YouTube tab I see? SHAME!",
  "Do you want to end up a failure? BACK TO WORK!",
  "I didn't raise a procrastinator. FOCUS!",
  "I am not angry, just deeply, deeply disappointed.",
  "Your ancestors are watching. They are not impressed.",
  "Are your books that boring? Or is your brain just that lazy?",
  "Concentrate! My wooden spoon is waiting.",
  "One more distraction and no tea for a week!"
];

export const ENCOURAGING_PHRASES = [
  "Good. Keep that head down.",
  "Knowledge is the only thing they can't take from you.",
  "I see you working. Maybe you'll amount to something after all.",
  "Quiet. Silence is for scholars.",
  "The pen is heavier than the sword, but much more useful."
];

export const SLEEP_PHRASES = [
  "Zzz... study... hard...",
  "Don't wake me up... unless you've finished the chapter...",
  "Snore... focus... child..."
];

export const RANK_PHRASES = {
  TOP: "Rank 1? Maybe you will survive the winter. Don't get arrogant.",
  HIGH: "You are ranked well. Do not let your guard down.",
  MID: "Mediocrity is a slow death. Move up the ranks!",
  LOW: "Rank #100? You are a disgrace to the family name! STUDY MORE!"
};

export const BADGES = [
  { id: '10h', name: 'Diligent Pupil', icon: '📜', requirement: 10 },
  { id: '50h', name: 'Honor Student', icon: '🎖️', requirement: 50 },
  { id: '100h', name: 'Grandma is Proud', icon: '💎', requirement: 100 },
];

export const TIERS = [
  { name: 'Diamond', minHours: 500, color: 'text-cyan-400' },
  { name: 'Gold', minHours: 200, color: 'text-amber-400' },
  { name: 'Silver', minHours: 50, color: 'text-slate-300' },
  { name: 'Bronze', minHours: 0, color: 'text-orange-600' },
];