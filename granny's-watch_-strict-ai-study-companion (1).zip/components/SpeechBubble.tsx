import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface SpeechBubbleProps {
  text: string;
  isAngry?: boolean;
}

export const SpeechBubble: React.FC<SpeechBubbleProps> = ({ text, isAngry }) => {
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={text}
        initial={{ opacity: 0, y: 15, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className={`relative mt-8 px-8 py-6 rounded-lg border-2 max-w-sm text-center font-classic text-xl transition-all duration-500 ${
          isAngry 
            ? 'bg-rose-950/90 border-rose-500 text-rose-50 shadow-[0_0_30px_rgba(225,29,72,0.4)]' 
            : 'bg-stone-900/90 border-stone-700 text-stone-100 shadow-2xl'
        }`}
      >
        {/* Parchment texture effect via CSS */}
        <div className="absolute inset-0 opacity-10 pointer-events-none mix-blend-overlay bg-[url('https://www.transparenttextures.com/patterns/dark-matter.png')]" />
        
        {/* Tail */}
        <div className={`absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 rotate-45 border-t-2 border-l-2 transition-colors duration-500 ${
          isAngry ? 'bg-rose-950/90 border-rose-500' : 'bg-stone-900/90 border-stone-700'
        }`} />
        
        <span className="relative z-10 italic leading-relaxed">
          {isAngry && <span className="block text-xs uppercase tracking-widest font-bold mb-2 text-rose-400">Warning:</span>}
          "{text}"
        </span>
      </motion.div>
    </AnimatePresence>
  );
};