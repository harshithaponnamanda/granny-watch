import React from 'react';
import { motion } from 'framer-motion';
import { GrannyState } from '../types';

interface GrannyProps {
  state: GrannyState;
}

export const GrannyCharacter: React.FC<GrannyProps> = ({ state }) => {
  const isAngry = state === GrannyState.ANGRY;
  const isSuspicious = state === GrannyState.SUSPICIOUS;
  const isSleeping = state === GrannyState.SLEEPING;
  const isIdle = state === GrannyState.IDLE;
  const isWatching = state === GrannyState.WATCHING;

  // Refined Color Palette for Realism
  const skinBase = "#fde2e4";
  const skinShadow = "#f3bac1";
  const hairBase = "#f1f5f9";
  const hairStrands = "#cbd5e1";
  const shawlBase = "#4c0519"; // Deep burgundy
  const shawlHighlight = "#881337";
  const blouseColor = "#1e1b4b"; 
  const wrinkleColor = "#a54b5b";

  return (
    <div className="relative w-64 h-64 md:w-80 md:h-80 flex items-center justify-center">
      {/* Dynamic Background Glow - Aura of authority */}
      <div className={`absolute inset-0 rounded-full blur-[80px] opacity-25 transition-all duration-1000 ${
        isAngry ? 'bg-rose-700' : isSuspicious ? 'bg-orange-700' : isWatching ? 'bg-emerald-700' : 'bg-slate-700'
      }`} />

      <motion.svg
        viewBox="0 0 200 200"
        className="w-full h-full drop-shadow-[0_25px_25px_rgba(0,0,0,0.5)]"
        initial={false}
        animate={
          isAngry ? { 
            x: [0, -1, 1, -1, 1, 0], 
            y: [0, 0.5, -0.5, 0.5, -0.5, 0] 
          } : 
          isSuspicious ? { 
            rotate: [0, -0.5, 0.5, -0.5, 0],
          } : 
          isIdle ? { y: [0, -1, 0] } : {}
        }
        transition={isAngry ? { repeat: Infinity, duration: 0.2 } : { repeat: Infinity, duration: 5, ease: "easeInOut" }}
      >
        <defs>
          <radialGradient id="faceGrad" cx="50%" cy="40%" r="60%">
            <stop offset="0%" stopColor={skinBase} />
            <stop offset="70%" stopColor={skinShadow} />
            <stop offset="100%" stopColor="#e2919d" />
          </radialGradient>
          
          <linearGradient id="shawlGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={shawlHighlight} />
            <stop offset="50%" stopColor={shawlBase} />
            <stop offset="100%" stopColor="#2d0611" />
          </linearGradient>

          <filter id="skinTexture" x="-10%" y="-10%" width="120%" height="120%">
            <feTurbulence type="fractalNoise" baseFrequency="0.05" numOctaves="3" result="noise" />
            <feDisplacementMap in="SourceGraphic" in2="noise" scale="1.5" />
          </filter>

          <filter id="softShadow">
            <feDropShadow dx="0" dy="1" stdDeviation="1" floodOpacity="0.3" />
          </filter>
        </defs>

        {/* Torso & Clothing */}
        <g id="clothing">
          <path d="M40 155 Q100 130 160 155 L180 200 L20 200 Z" fill={blouseColor} />
          <motion.path 
            d="M30 160 Q70 140 130 155 Q170 170 175 200 L25 200 Z" 
            fill="url(#shawlGrad)" 
            animate={isAngry ? { scale: 1.01 } : { scale: 1 }}
          />
          {/* Brooch */}
          <circle cx="100" cy="155" r="5" fill="#ca8a04" />
          <circle cx="100" cy="155" r="2.5" fill="#facc15" />
        </g>

        {/* Head Group */}
        <motion.g 
          id="head"
          animate={
            isAngry ? { rotate: [0, -0.3, 0.3, 0] } :
            isSuspicious ? { x: [0, 0.4, -0.4, 0] } : {}
          }
          transition={{ repeat: Infinity, duration: 0.15 }}
        >
          {/* Hair Bun - Textured */}
          <circle cx="100" cy="38" r="24" fill={hairBase} />
          <path d="M85 30 Q100 20 115 30" stroke={hairStrands} strokeWidth="1" fill="none" opacity="0.5" />

          {/* Face Shape - More "Jowly" and Realistic */}
          <path 
            d="M55 85 
               Q55 40 100 40 
               Q145 40 145 85 
               Q145 115 135 135 
               Q100 145 65 135 
               Q55 115 55 85" 
            fill="url(#faceGrad)"
            filter="url(#softShadow)"
          />

          {/* Hair - Stranded look */}
          <path d="M55 85 Q55 40 100 40 L100 50 Q75 50 65 85 Z" fill={hairBase} />
          <path d="M145 85 Q145 40 100 40 L100 50 Q125 50 135 85 Z" fill={hairBase} />
          <g opacity="0.4">
             <path d="M60 65 Q75 55 100 55" stroke={hairStrands} fill="none" />
             <path d="M140 65 Q125 55 100 55" stroke={hairStrands} fill="none" />
          </g>

          {/* Realistic Features */}
          <g id="features">
            {/* Age spots / Pigmentation */}
            <circle cx="70" cy="115" r="1.5" fill={wrinkleColor} opacity="0.2" />
            <circle cx="130" cy="105" r="1" fill={wrinkleColor} opacity="0.2" />
            <circle cx="125" cy="125" r="1.2" fill={wrinkleColor} opacity="0.15" />

            {/* Forehead Wrinkles - Deepening */}
            <g opacity="0.7">
              <path d="M82 58 Q100 54 118 58" stroke={wrinkleColor} strokeWidth="1.2" fill="none" strokeLinecap="round" />
              <path d="M86 63 Q100 60 114 63" stroke={wrinkleColor} strokeWidth="0.8" fill="none" strokeLinecap="round" />
            </g>

            {/* Eyes & Lids */}
            <g transform="translate(0, 4)">
              {isSleeping ? (
                <>
                  <path d="M72 82 Q85 88 98 82" stroke="#451a03" strokeWidth="2.5" fill="none" />
                  <path d="M102 82 Q115 88 128 82" stroke="#451a03" strokeWidth="2.5" fill="none" />
                  {/* Under eye bags */}
                  <path d="M75 92 Q85 96 95 92" stroke={wrinkleColor} strokeWidth="0.5" fill="none" opacity="0.4" />
                  <path d="M105 92 Q115 96 125 92" stroke={wrinkleColor} strokeWidth="0.5" fill="none" opacity="0.4" />
                </>
              ) : (
                <>
                  {/* Eye Sockets */}
                  <ellipse cx="85" cy="85" rx="12" ry="10" fill="#f8bbd0" opacity="0.3" />
                  <ellipse cx="115" cy="85" rx="12" ry="10" fill="#f8bbd0" opacity="0.3" />
                  
                  <circle cx="85" cy="84" r={isAngry ? 9 : 8} fill="white" />
                  <circle cx="115" cy="84" r={isAngry ? 9 : 8} fill="white" />
                  
                  {/* Pupils with reflections */}
                  <g>
                    <motion.circle 
                      cx="85" cy="84" r={isAngry ? 6 : 4} 
                      fill={isAngry ? "#7f1d1d" : "#0f172a"}
                      animate={isSuspicious ? { x: [-1.5, 1.5, -1.5], transition: { duration: 0.8, repeat: Infinity } } : {}}
                    />
                    <circle cx="83" cy="82" r="1.5" fill="white" opacity="0.8" />
                  </g>
                  
                  <g>
                    <motion.circle 
                      cx="115" cy="84" r={isAngry ? 6 : 4} 
                      fill={isAngry ? "#7f1d1d" : "#0f172a"}
                      animate={isSuspicious ? { x: [-1.5, 1.5, -1.5], transition: { duration: 0.8, repeat: Infinity } } : {}}
                    />
                    <circle cx="113" cy="82" r="1.5" fill="white" opacity="0.8" />
                  </g>

                  {/* Lids - Droopy lids for realism */}
                  <path d="M73 78 Q85 74 97 78" stroke={wrinkleColor} strokeWidth="0.5" fill="none" opacity="0.6" />
                  <path d="M103 78 Q115 74 127 78" stroke={wrinkleColor} strokeWidth="0.5" fill="none" opacity="0.6" />
                </>
              )}
            </g>

            {/* Eyebrows - Bushy & Gray */}
            <motion.path 
              d={isAngry ? "M68 68 L96 82 M104 82 L132 68" : "M72 72 Q85 66 98 72 M102 72 Q115 66 128 72"}
              stroke={hairStrands} strokeWidth="3" fill="none" strokeLinecap="round"
              animate={isAngry ? { y: [-0.5, 0.5, -0.5] } : {}}
              transition={{ repeat: Infinity, duration: 0.3 }}
            />

            {/* Nose - More defined shape */}
            <path d="M96 95 Q100 90 104 95 Q104 105 100 108 Q96 105 96 95" fill={skinShadow} opacity="0.5" />
            <path d="M97 108 Q100 111 103 108" stroke={wrinkleColor} strokeWidth="0.5" fill="none" />

            {/* Glasses - Realistic frame thickness and reflections */}
            <g stroke="#1e293b" strokeWidth="1.8" fill="none">
              <circle cx="85" cy="89" r="15" />
              <circle cx="115" cy="89" r="15" />
              <path d="M100 89 L100 89" strokeLinecap="round" />
              <path d="M70 89 L60 85" strokeWidth="1" opacity="0.5" />
              <path d="M130 89 L140 85" strokeWidth="1" opacity="0.5" />
              {/* Lens Reflection */}
              <path d="M78 82 L82 78" stroke="white" strokeWidth="1" opacity="0.3" />
              <path d="M108 82 L112 78" stroke="white" strokeWidth="1" opacity="0.3" />
            </g>

            {/* Mouth & Nasolabial Folds (Laughter lines) */}
            <g>
              {/* Folds */}
              <path d="M80 105 Q75 115 85 125" stroke={wrinkleColor} strokeWidth="0.5" fill="none" opacity="0.4" />
              <path d="M120 105 Q125 115 115 125" stroke={wrinkleColor} strokeWidth="0.5" fill="none" opacity="0.4" />
              
              {/* Mouth */}
              <motion.path
                d={isAngry ? "M85 120 Q100 110 115 120" : isSleeping ? "M94 118 Q100 122 106 118" : "M88 122 Q100 125 112 122"}
                stroke="#4c0519" strokeWidth="3" fill="none" strokeLinecap="round"
                animate={isAngry ? { scaleY: [1, 1.3, 1] } : {}}
                transition={{ repeat: Infinity, duration: 0.15 }}
              />
            </g>
          </g>
        </motion.g>

        {/* Zzz for Sleep state */}
        {isSleeping && (
          <motion.g
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 1, 0], y: [0, -40], x: [0, 15] }}
            transition={{ repeat: Infinity, duration: 3 }}
          >
            <text x="145" y="55" fontSize="18" fill={hairStrands} className="font-bold italic">Zzz</text>
          </motion.g>
        )}
      </motion.svg>
      
      {/* Subtle Breathing Overlay for "Life" */}
      <motion.div 
        className="absolute inset-0 rounded-full border border-white/5 pointer-events-none"
        animate={{ scale: [1, 1.02, 1], opacity: [0.1, 0.2, 0.1] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
      />
    </div>
  );
};