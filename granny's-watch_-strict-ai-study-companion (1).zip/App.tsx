import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { AppView, SessionConfig, User } from './types';
import { Landing } from './views/Landing';
import { Setup } from './views/Setup';
import { Session } from './views/Session';
import { CharacterSelect } from './views/CharacterSelect';
import { Leaderboard } from './views/Leaderboard';
import { Auth } from './views/Auth';
import { AuthService } from './services/AuthService';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.LANDING);
  const [user, setUser] = useState<User | null>(null);
  const [sessionConfig, setSessionConfig] = useState<SessionConfig | null>(null);

  useEffect(() => {
    const currentUser = AuthService.getCurrentUser();
    if (currentUser) setUser(currentUser);
  }, []);

  const handleAuthSuccess = (authenticatedUser: User) => {
    setUser(authenticatedUser);
    setView(AppView.LANDING);
  };

  const handleLogout = () => {
    AuthService.logout();
    setUser(null);
    setView(AppView.LANDING);
  };

  const startFlow = () => {
    if (!user) {
      setView(AppView.AUTH);
    } else {
      setView(AppView.CHARACTER_SELECT);
    }
  };
  
  const handleCharacterSelected = (id: string) => {
    setView(AppView.SETUP);
  };

  const handleSetupComplete = (config: SessionConfig) => {
    setSessionConfig(config);
    setView(AppView.SESSION);
  };

  const handleSessionFinish = () => {
    setView(AppView.LANDING);
    setSessionConfig(null);
  };

  const showLeaderboard = () => setView(AppView.LEADERBOARD);
  const hideLeaderboard = () => setView(AppView.LANDING);

  return (
    <div className="min-h-screen selection:bg-amber-500 selection:text-white bg-slate-950 text-slate-100 relative">
      <div className="fixed inset-0 -z-10 opacity-30 bg-[radial-gradient(circle_at_50%_-20%,#451a03,transparent_60%)]" />
      
      {/* Persistent UI Elements */}
      {view === AppView.LANDING && (
        <div className="fixed top-8 right-8 z-50 flex gap-4">
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            onClick={showLeaderboard}
            className="bg-slate-900/80 backdrop-blur border border-slate-800 px-6 py-3 rounded-full flex items-center gap-3 hover:bg-slate-800 transition-all text-xs font-bold uppercase tracking-widest text-amber-500 shadow-xl"
          >
            <span>🏆</span>
            Leaderboard
          </motion.button>
        </div>
      )}

      <main className="container mx-auto px-4 py-8 relative">
        <AnimatePresence mode="wait">
          {view === AppView.LANDING && (
            <motion.div
              key="landing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
            >
              <Landing 
                onStart={startFlow} 
                onAuth={() => setView(AppView.AUTH)} 
                user={user}
                onLogout={handleLogout}
              />
            </motion.div>
          )}

          {view === AppView.AUTH && (
            <motion.div
              key="auth"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.1 }}
              transition={{ duration: 0.4 }}
            >
              <Auth 
                onSuccess={handleAuthSuccess} 
                onBack={() => setView(AppView.LANDING)} 
              />
            </motion.div>
          )}

          {view === AppView.CHARACTER_SELECT && (
            <motion.div
              key="char-select"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.5 }}
            >
              <CharacterSelect onSelect={handleCharacterSelected} />
            </motion.div>
          )}

          {view === AppView.SETUP && (
            <motion.div
              key="setup"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.5 }}
            >
              <Setup onComplete={handleSetupComplete} />
            </motion.div>
          )}

          {view === AppView.LEADERBOARD && (
            <motion.div
              key="leaderboard"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.6 }}
            >
              <Leaderboard onBack={hideLeaderboard} />
            </motion.div>
          )}

          {view === AppView.SESSION && sessionConfig && (
            <motion.div
              key="session"
              initial={{ opacity: 0, scale: 1.05 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1 }}
            >
              <Session 
                config={sessionConfig} 
                onFinish={handleSessionFinish} 
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <footer className="fixed bottom-4 left-0 w-full text-center pointer-events-none opacity-10 transition-opacity hover:opacity-100 duration-700">
        <p className="text-[10px] uppercase tracking-[0.5em] font-bold text-slate-600">
          Strict Study Protocol // Secured by Granny's Watch
        </p>
      </footer>
    </div>
  );
};

export default App;